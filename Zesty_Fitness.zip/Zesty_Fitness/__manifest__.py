{
'name': 'Zesty Fitness',
'version': '18.0.0.0',
'summary': 'Manage Gym Memberships, Trainers and Scheduling',
'description': """ Welcome to Zesty Fitness """,
'category':'',
'author': ' Vikas V ',
'website': 'www.zbeanztech.com',
"license": "LGPL-3",
'depends': [ ],
'data': [
    'Security/ir.model.access.csv',
    'Views/zb_fitness.xml',
    'Views/fitness_menu.xml',
    
],
'test': [],
'demo': [],
'installable': True,
'auto_install': False,
'application': False,
}